<?php
  header("Location: ExampleApp");
  die();
?>
