<?php
class AppHelper { }
include_once(dirname(__FILE__)."/../GoogleMapHelper.php");
?>